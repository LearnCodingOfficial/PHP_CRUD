<?php
include "include/config.php";
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $pincode = $_POST['pincode'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $sql_query = "INSERT INTO `user_data`(`id`, `name`, `email`, `phone`, `pincode`, `gender`, `address`) VALUES
    (NULL,'$name','$email','$phone','$pincode','$gender','$address')";
    $result = mysqli_query($connection, $sql_query);
    if ($result) {
        echo "<script> alert('Data SuccessFully Added') </script>";
        echo "<script> location.replace('index.php') </script>";
    } else {
        echo $connection->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get Php Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

</head>

<body>
    <div class="text-center">
    <!-- <h2 class="text-primary">PHP GET Method Form</h2> -->
        <h2 class="text-primary">PHP POST Method Form</h2>

    </div>
    <div class="container p-5 card">
        <form method="POST" action="" class="">
            <div class="row ">
                <div class="col-sm-4">
                    <label class="label" for="">name</label>
                    <input class="form-control" type="text" placeholder="Enter Your Name" name="name">
                </div>
                <div class="col-sm-4">
                    <label class="label" for="">Email</label>
                    <input class="form-control" type="email" placeholder="Enter Your Valid Email Address" name="email">
                </div>
                <div class="col-sm-4">
                    <label class="label" for="">Phone</label>
                    <input class="form-control" type="number" placeholder="Enter Your 10 digit valid mobile number" name="phone">
                </div>
                <div class="col-sm-4">
                    <label class="label" for="">Pin code</label>
                    <input class="form-control" type="number" placeholder="Enter Your 6 digit valid Pin Code" name="pincode">
                </div>
                <div class="col-sm-4">
                    <label class="label" for="">Gender</label>
                    <select class="form-control" type="text" placeholder="Enter Your 6 digit valid Pin Code" name="gender">
                        <option selected disabled> -Choose Gender- </option>
                        <option value="male">male</option>
                        <option value="female">female</option>
                        <option value="others">others</option>

                    </select>
                </div>
                <div class="col-sm-12">
                    <label class="label" for="">Address</label>
                    <textarea class="form-control" type="text" placeholder="Enter Your Address" name="address"></textarea>
                </div>
            </div>
            <div class="mt-4 text-center">
                <button name="submit" class="btn btn-success">Submit</button>
            </div>
        </form>
    </div>

</body>

</html>